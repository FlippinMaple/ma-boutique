import { useQuantityModal } from '../utils/modals';

const ProductCard = ({ product }) => {
  const showQuantity = useQuantityModal();

  const handleClick = () => {
    if (!product.variants || product.variants.length === 0) {
      console.warn('⛔ Aucun variant pour le produit:', product);
      return;
    }

    const variant = product.variants[0];

    const productData = {
      id: variant.id,
      variant_id: variant.variant_id,
      printful_variant_id: variant.printful_variant_id,
      name: product.name,
      price: variant.price || 29.99,
      image: variant.image || product.image
    };

    showQuantity(productData);
  };

  return (
    <div
      style={{
        border: '1px solid #ccc',
        borderRadius: '10px',
        padding: '1rem',
        width: '220px',
        background: '#fff',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}
    >
      <img
        src={product.image || (product.variants?.[0]?.image ?? '')}
        alt={product.name}
        style={{
          width: '100%',
          height: 'auto',
          borderRadius: '6px',
          marginBottom: '1rem'
        }}
      />
      <h4 style={{ margin: 0 }}>{product.name}</h4>
      <p style={{ margin: '0.5rem 0' }}>
        {product.variants?.[0]?.price
          ? `${Number(product.variants[0].price).toFixed(2)} $`
          : 'Prix non dispo'}
      </p>
      <button
        onClick={handleClick}
        style={{
          backgroundColor: '#1f8ef1',
          color: '#fff',
          border: 'none',
          padding: '0.5rem 1rem',
          borderRadius: '6px',
          cursor: 'pointer',
          fontWeight: 'bold'
        }}
      >
        Choisir quantité
      </button>
    </div>
  );
};

export default ProductCard;
