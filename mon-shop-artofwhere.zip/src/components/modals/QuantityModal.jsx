import { useState } from 'react';
import { useModal } from '../../context/ModalContext';
import toast from 'react-hot-toast';
import { useCart } from '../../CartContext';

const QuantityModal = ({ product }) => {
  const { closeModal } = useModal();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity
    });
    toast.success('Ajouté au panier !');
    closeModal();
  };

  const handleViewCart = () => {
    closeModal();
    window.location.href = '/checkout';
  };

  return (
    <div style={{ textAlign: 'center' }}>
      <h3>{product.name}</h3>
      <img
        src={product.image}
        alt={product.name}
        style={{ maxWidth: '100%', borderRadius: '8px', margin: '1rem 0' }}
      />
      <p>
        <strong>Prix :</strong> {product.price.toFixed(2)} $
      </p>
      <div style={{ margin: '1rem 0' }}>
        <label htmlFor="qty" style={{ marginRight: '0.5rem' }}>
          Quantité :
        </label>
        <select
          id="qty"
          value={quantity}
          onChange={(e) => setQuantity(parseInt(e.target.value, 10))}
          style={{
            padding: '8px',
            borderRadius: '6px',
            border: '1px solid #ccc',
            width: '60px'
          }}
        >
          {Array.from({ length: 5 }, (_, i) => (
            <option key={i + 1} value={i + 1}>
              {i + 1}
            </option>
          ))}
        </select>
      </div>
      <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem' }}>
        <button onClick={handleAddToCart} style={btnPrimary}>
          Ajouter
        </button>
        <button onClick={handleViewCart} style={btnSecondary}>
          Voir panier
        </button>
      </div>
    </div>
  );
};

const btnPrimary = {
  padding: '8px 16px',
  backgroundColor: '#28a745',
  color: '#fff',
  border: 'none',
  borderRadius: '6px',
  fontWeight: 'bold',
  cursor: 'pointer'
};

const btnSecondary = {
  ...btnPrimary,
  backgroundColor: '#007bff'
};

export default QuantityModal;
