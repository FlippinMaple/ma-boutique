const Home = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Bienvenue sur mon shop!</h1>
      <p>Découvrez nos t-shirts et cotons ouatés personnalisés.</p>
    </div>
  );
};

export default Home;
